////////////////////////////////////////////////////////////////////////////////
///                                                                          ///
///  ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░  ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓██████▓▒░░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ///
///  ░▒▓██████▓▒░ ░▒▓██████▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░  ///
///    ░▒▓█▓▒░                                                               ///
///     ░▒▓██▓▒░                                                             ///
///                                                                          ///
///   * QUIX LANG COMPILER - The official compiler for the Quix language.    ///
///   * Copyright (C) 2024 Wesley C. Jones                                   ///
///                                                                          ///
///   The QUIX Compiler Suite is free software; you can redistribute it or   ///
///   modify it under the terms of the GNU Lesser General Public             ///
///   License as published by the Free Software Foundation; either           ///
///   version 2.1 of the License, or (at your option) any later version.     ///
///                                                                          ///
///   The QUIX Compiler Suite is distributed in the hope that it will be     ///
///   useful, but WITHOUT ANY WARRANTY; without even the implied warranty of ///
///   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      ///
///   Lesser General Public License for more details.                        ///
///                                                                          ///
///   You should have received a copy of the GNU Lesser General Public       ///
///   License along with the QUIX Compiler Suite; if not, see                ///
///   <https://www.gnu.org/licenses/>.                                       ///
///                                                                          ///
////////////////////////////////////////////////////////////////////////////////

#include <quixcc/IR/Q/Function.h>

boost::uuids::uuid libquixcc::ir::q::Block::hash_impl() const {
  return Hasher().gettag().add(stmts).hash();
}

bool libquixcc::ir::q::Block::verify_impl() const {
  return std::all_of(stmts.begin(), stmts.end(), [](const Value *stmt) { return stmt->verify(); });
}

boost::uuids::uuid libquixcc::ir::q::Segment::hash_impl() const {
  auto h = Hasher().gettag().add(return_type);

  for (const auto &p : params)
    h.add(p.first).add(p.second);

  h.add(is_variadic)
      .add(is_pure)
      .add(is_thread_safe)
      .add(is_no_throw)
      .add(is_no_return)
      .add(is_foriegn);

  if (block)
    h.add(block);

  return h.hash();
}

bool libquixcc::ir::q::Segment::verify_impl() const {
  if (!std::all_of(params.begin(), params.end(),
                   [](const auto param) { return param.second->verify(); }) &&
      return_type->verify()) {
    return false;
  }

  if (block)
    return block->verify();

  return true;
}

boost::uuids::uuid libquixcc::ir::q::RootNode::hash_impl() const {
  return Hasher().gettag().add(children).hash();
}

bool libquixcc::ir::q::RootNode::verify_impl() const {
  return std::all_of(children.begin(), children.end(),
                     [](const Value *child) { return child->verify(); });
}