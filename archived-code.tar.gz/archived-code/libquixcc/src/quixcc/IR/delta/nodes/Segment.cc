////////////////////////////////////////////////////////////////////////////////
///                                                                          ///
///  ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░  ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓██████▓▒░░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ///
///  ░▒▓██████▓▒░ ░▒▓██████▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░  ///
///    ░▒▓█▓▒░                                                               ///
///     ░▒▓██▓▒░                                                             ///
///                                                                          ///
///   * QUIX LANG COMPILER - The official compiler for the Quix language.    ///
///   * Copyright (C) 2024 Wesley C. Jones                                   ///
///                                                                          ///
///   The QUIX Compiler Suite is free software; you can redistribute it or   ///
///   modify it under the terms of the GNU Lesser General Public             ///
///   License as published by the Free Software Foundation; either           ///
///   version 2.1 of the License, or (at your option) any later version.     ///
///                                                                          ///
///   The QUIX Compiler Suite is distributed in the hope that it will be     ///
///   useful, but WITHOUT ANY WARRANTY; without even the implied warranty of ///
///   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      ///
///   Lesser General Public License for more details.                        ///
///                                                                          ///
///   You should have received a copy of the GNU Lesser General Public       ///
///   License along with the QUIX Compiler Suite; if not, see                ///
///   <https://www.gnu.org/licenses/>.                                       ///
///                                                                          ///
////////////////////////////////////////////////////////////////////////////////

#include <quixcc/IR/delta/Segment.h>

boost::uuids::uuid libquixcc::ir::delta::Block::hash_impl() const {
  return Hasher().gettag().add(stmts).hash();
}

bool libquixcc::ir::delta::Block::verify_impl() const {
  return std::all_of(stmts.begin(), stmts.end(), [](const Value *v) { return v->verify(); });
}

boost::uuids::uuid libquixcc::ir::delta::Segment::hash_impl() const {
  auto h = Hasher().gettag().add(ret).add(variadic);
  for (auto &p : params)
    h.add(p.second);

  if (block)
    h.add(block);

  return h.hash();
}

bool libquixcc::ir::delta::Segment::verify_impl() const {
  for (auto &p : params)
    if (!p.second->verify())
      return false;

  if (block)
    if (!block->verify())
      return false;

  return ret->verify();
}

boost::uuids::uuid libquixcc::ir::delta::Asm::hash_impl() const {
  auto h = Hasher().gettag().add(asm_str);

  for (auto &p : outputs)
    h.add(p.first).add(p.second);
  for (auto &p : inputs)
    h.add(p.first).add(p.second);
  for (auto &p : clobbers)
    h.add(p);

  return h.hash();
}

bool libquixcc::ir::delta::Asm::verify_impl() const {
  if (!std::all_of(outputs.begin(), outputs.end(),
                   [](const auto &p) { return p.second->verify(); })) {
    return false;
  }

  if (!std::all_of(inputs.begin(), inputs.end(),
                   [](const auto &p) { return p.second->verify(); })) {
    return false;
  }

  return true;
}

boost::uuids::uuid libquixcc::ir::delta::RootNode::hash_impl() const {
  auto h = Hasher().gettag();

  for (auto &s : children)
    h.add(s);

  return h.hash();
}

bool libquixcc::ir::delta::RootNode::verify_impl() const {
  for (auto &s : children)
    if (!s->verify())
      return false;

  return true;
}
