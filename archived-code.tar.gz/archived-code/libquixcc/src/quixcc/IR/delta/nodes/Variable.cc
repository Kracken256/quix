////////////////////////////////////////////////////////////////////////////////
///                                                                          ///
///  ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░  ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓██████▓▒░░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ///
///  ░▒▓██████▓▒░ ░▒▓██████▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░  ///
///    ░▒▓█▓▒░                                                               ///
///     ░▒▓██▓▒░                                                             ///
///                                                                          ///
///   * QUIX LANG COMPILER - The official compiler for the Quix language.    ///
///   * Copyright (C) 2024 Wesley C. Jones                                   ///
///                                                                          ///
///   The QUIX Compiler Suite is free software; you can redistribute it or   ///
///   modify it under the terms of the GNU Lesser General Public             ///
///   License as published by the Free Software Foundation; either           ///
///   version 2.1 of the License, or (at your option) any later version.     ///
///                                                                          ///
///   The QUIX Compiler Suite is distributed in the hope that it will be     ///
///   useful, but WITHOUT ANY WARRANTY; without even the implied warranty of ///
///   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      ///
///   Lesser General Public License for more details.                        ///
///                                                                          ///
///   You should have received a copy of the GNU Lesser General Public       ///
///   License along with the QUIX Compiler Suite; if not, see                ///
///   <https://www.gnu.org/licenses/>.                                       ///
///                                                                          ///
////////////////////////////////////////////////////////////////////////////////

#include <quixcc/IR/delta/Variable.h>

boost::uuids::uuid libquixcc::ir::delta::Local::hash_impl() const {
  return Hasher().gettag().add(name).add(type).hash();
}

bool libquixcc::ir::delta::Local::verify_impl() const { return type->verify(); }

boost::uuids::uuid libquixcc::ir::delta::Global::hash_impl() const {
  return Hasher().gettag().add(name).add(type).add(value).add(_volatile).add(_atomic).hash();
}

bool libquixcc::ir::delta::Global::verify_impl() const {
  if (value) {
    return type->verify() && value->verify();
  } else {
    return type->verify();
  }
}

boost::uuids::uuid libquixcc::ir::delta::Number::hash_impl() const {
  return Hasher().gettag().add(value).hash();
}

bool libquixcc::ir::delta::Number::verify_impl() const { return true; }

boost::uuids::uuid libquixcc::ir::delta::String::hash_impl() const {
  return Hasher().gettag().add(value).hash();
}

bool libquixcc::ir::delta::String::verify_impl() const { return true; }

boost::uuids::uuid libquixcc::ir::delta::List::hash_impl() const {
  auto h = Hasher().gettag();
  for (auto &v : values) {
    h.add(v);
  }
  return h.hash();
}

bool libquixcc::ir::delta::List::verify_impl() const {
  for (auto &v : values) {
    if (!v->verify())
      return false;
  }
  return true;
}