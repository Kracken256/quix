////////////////////////////////////////////////////////////////////////////////
///                                                                          ///
///  ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░  ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓██████▓▒░░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        ///
/// ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ///
///  ░▒▓██████▓▒░ ░▒▓██████▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ░▒▓██████▓▒░  ///
///    ░▒▓█▓▒░                                                               ///
///     ░▒▓██▓▒░                                                             ///
///                                                                          ///
///   * QUIX LANG COMPILER - The official compiler for the Quix language.    ///
///   * Copyright (C) 2024 Wesley C. Jones                                   ///
///                                                                          ///
///   The QUIX Compiler Suite is free software; you can redistribute it or   ///
///   modify it under the terms of the GNU Lesser General Public             ///
///   License as published by the Free Software Foundation; either           ///
///   version 2.1 of the License, or (at your option) any later version.     ///
///                                                                          ///
///   The QUIX Compiler Suite is distributed in the hope that it will be     ///
///   useful, but WITHOUT ANY WARRANTY; without even the implied warranty of ///
///   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      ///
///   Lesser General Public License for more details.                        ///
///                                                                          ///
///   You should have received a copy of the GNU Lesser General Public       ///
///   License along with the QUIX Compiler Suite; if not, see                ///
///   <https://www.gnu.org/licenses/>.                                       ///
///                                                                          ///
////////////////////////////////////////////////////////////////////////////////

#define QUIXCC_INTERNAL

#include <quixcc/core/Logger.h>
#include <qast/Lexer.h>
#include <quixcc/preprocessor/Preprocessor.h>

#include <regex>

static bool match_format(const std::string &str) {
  static std::regex re("v[0-9]+\\.[0-9]+");
  return std::regex_match(str, re);
}

bool libquixcc::PrepEngine::ParseUse(const Token &tok, const std::string &directive,
                                     const std::string &parameter) {
  (void)tok;
  (void)directive;

  auto lexer = clone();
  lexer->set_source(parameter, "<use-macro>");

  Token tok2 = lexer->next();
  if (tok2.type() != tText) {
    LOG(ERROR) << "Invalid parameter for use directive" << tok << std::endl;
    return false;
  }

  std::string version = tok2.as<std::string>();

  if (version == "undef") {
    job->version = std::nullopt;
    return true;
  }

  if (!match_format(version)) {
    LOG(ERROR) << "Invalid version format for use directive" << tok << std::endl;
    return false;
  }

  uint major = std::stoi(version.substr(1, version.find('.')));
  uint minor = std::stoi(version.substr(version.find('.') + 1));

  job->version = std::make_pair(major, minor);

  if (!quixcc_has_version(major, minor)) {
    LOG(ERROR) << "Language version [" << major << "." << minor
               << "] is not supported by this toolchain" << tok << std::endl;

    return false;
  }

  return true;
}